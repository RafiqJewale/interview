<?php
namespace Drupal\custom\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\node\Entity\Node;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Controller for custom module.
 */
class CustomController extends ControllerBase {

  /**
   * Returns node as JSON.
   */
  public function nodeJson() {
    $site_api_key_config = \Drupal::state()->get('siteapikey');
    $site_api_key = \Drupal::routeMatch()->getParameter('siteapikey');
    $nid = \Drupal::routeMatch()->getParameter('nid');
    if(isset($site_api_key_config) && isset($nid) && $site_api_key_config == $site_api_key){
      $serializer = \Drupal::service('serializer');
      $node = Node::load($nid);
      $data = $serializer->serialize($node, 'json', ['plugin_id' => 'entity']);
      return [
        '#markup' => $data,
      ]; 
    }
    else{
      throw new \Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException();
    }
  }

}